Ext.application({
    name: 'extComponent',
    
	appFolder: getRootPath()+'/watfh/extComponent',
	
    requires: [ 'extComponent.controller.extComController' ],

    mainView: 'extComponent.view.extComMain'
});
