Ext.define('common.view.commonMain', {
	extend : 'Ext.panel.Panel',
	id : 'commonMain' + module,
	alias : 'widget.commonMain' + module,
	controller: 'main',
	layout :  'border',
	bodyStyle: {
	    background: '#fff',
	},
	border : false
});
