Ext.application({
    name: 'impexpdata',
	appFolder: getRootPath()+'/watfh/system/impExpData',
    requires: [ 'impexpdata.controller.MainController'],
    mainView: 'impexpdata.view.impExpDataMain'
});
