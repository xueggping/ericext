Ext.application({
    name: 'function',
    
	appFolder:  getRootPath()+'/watfh/system/function',
	
    requires: [
        'function.controller.MainController'
    ],

    mainView: 'function.view.FunctionMain'
});
