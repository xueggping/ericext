Ext.application({
    name: 'dictionary',
    
	appFolder:  getRootPath()+'/watfh/system/dictionary',
	
    requires: [
        'dictionary.controller.MainController'
    ],

    mainView: 'dictionary.view.DictionaryMain'
});
