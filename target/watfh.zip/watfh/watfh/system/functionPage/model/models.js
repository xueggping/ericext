Ext.define('functionpage.model.models', {  
    extend: 'Ext.data.Model',  
    fields : ['id', 'componentname','xtype','width','height','margin','labelWidth','actionName','maxLength','fieldLabel','allowBlank','regex','regexText','maxLengthText','otherProperty','extendComponent','ordered','hidden','text','dataIndex','pageId' ]
});  