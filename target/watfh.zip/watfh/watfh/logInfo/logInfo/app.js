Ext.application({
    name: 'logInfo',
	appFolder: getRootPath()+'/watfh/logInfo/logInfo',
    requires: [ 'logInfo.controller.LoginfoMainController' ],
    mainView: 'logInfo.view.LoginfoMain'
});