Ext.application({
    name: 'zhdzcx',
    
	appFolder: getRootPath()+'/watfh/zhdzcx',
	
    requires: [ 'zhdzcx.controller.zhdzcxController' ],

    mainView: 'zhdzcx.view.zhdzcxMain'
});
