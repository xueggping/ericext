Ext.application({
    name: 'main',
    
	appFolder: getRootPath()+'/watfh/main',
	
    requires: [
        'main.controller.MainController'
    ],

    mainView: 'main.view.Main'
});
